import java.util.LinkedList;
import java.util.Scanner;
class MyFirendsContacts {
    String name;
    String phoneNumber;
    String email;
    public MyFirendsContacts(String name, String phoneNumber, String email) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }
}

public class ContactBook {
    public static void main(String[] args) {
        LinkedList<MyFirendsContacts> contacts = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("What do you wanna do?:");
            System.out.println("1. Add Contact");
            System.out.println("2. Delete Contact");
            System.out.println("3. Search by Email");
            System.out.println("4. Print Contact List");
            System.out.println("5. Search Contact");
            System.out.println("6. Quit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    contacts.add(new MyFirendsContacts (name, phoneNumber, email));
                    break;
                case 2:
                    System.out.print("Enter Email to Delete: ");
                    String emailToDelete = scanner.nextLine();
                    contacts.removeIf(contact -> contact.email.equals(emailToDelete));
                    break;
                case 3:
                    System.out.print("Enter Email to Search: ");
                    String emailToSearch = scanner.nextLine();
                    for (MyFirendsContacts contact : contacts) {
                        if (contact.email.equals(emailToSearch)) {
                            System.out.println("Contact Found:");
                            System.out.println("Name: " + contact.name);
                            System.out.println("Phone Number: " + contact.phoneNumber);
                            System.out.println("Email: " + contact.email);
                            break;
                        }
                    }
                    break;
                case 4:
                    System.out.println("Contact List:");
                    for (MyFirendsContacts contact : contacts) {
                        System.out.println("Name: " + contact.name + ", Phone Number: " + contact.phoneNumber + ", Email: " + contact.email);
                    }
                    break;
                case 5:
                    System.out.print("Enter Name to Search: ");
                    String nameToSearch = scanner.nextLine();
                    for (MyFirendsContacts contact : contacts) {
                        if (contact.name.equals(nameToSearch)) {
                            System.out.println("Contact Found:");
                            System.out.println("Name: " + contact.name);
                            System.out.println("Phone Number: " + contact.phoneNumber);
                            System.out.println("Email: " + contact.email);
                            break;
                        }
                    }
                    break;
                case 6:
                    running = false;
                    System.out.println("Haha leaving for the day. See yah buddy!");
                    break;
                default:
                    System.out.println("Error. Please wear your glasses and try again.");
            }
        }
        scanner.close();
    }
}
